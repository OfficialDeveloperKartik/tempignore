// ===== WATERING CAR (WC) - Seeeduino v4.3 =====
// Wiring:
//   Grove Relay -> D4  (pump wired through relay NO + COM)
//   HC-05       -> D2 (HC-05 TX -> D2), D3 (D3 -> HC-05 RX, via 3.3V divider if bare module)
//   L298N: ENA -> D5, IN1 -> D7, IN2 -> D8   (LEFT side: both left motors in parallel on OUT1/OUT2)
//          ENB -> D6, IN3 -> D9, IN4 -> D10  (RIGHT side: both right motors in parallel on OUT3/OUT4)
//   Common GND between Seeeduino, L298N and HC-05.
//
// Protocol from CC:  'W' = start watering,  'S' = stop pump & return
// Protocol to CC:    'D' = done, car is back home

#include <SoftwareSerial.h>

SoftwareSerial bt(2, 3);   // RX, TX

const int PIN_RELAY = 4;
const int ENA = 5, IN1 = 7, IN2 = 8;
const int ENB = 6, IN3 = 9, IN4 = 10;

const int  MOTOR_SPEED = 200;                 // 0-255
const unsigned long DRIVE_MS = 3000;          // forward / backward time
const unsigned long PUMP_MAX_MS = 120000UL;   // failsafe: pump never runs longer than this

enum State { IDLE, FWD, PUMPING, BWD };
State state = IDLE;
unsigned long stateStart = 0;

void motors(int dir) {   // 1 = forward, -1 = backward, 0 = stop
  if (dir == 0) {
    analogWrite(ENA, 0); analogWrite(ENB, 0);
    digitalWrite(IN1, LOW); digitalWrite(IN2, LOW);
    digitalWrite(IN3, LOW); digitalWrite(IN4, LOW);
    return;
  }
  digitalWrite(IN1, dir > 0); digitalWrite(IN2, dir < 0);
  digitalWrite(IN3, dir > 0); digitalWrite(IN4, dir < 0);
  analogWrite(ENA, MOTOR_SPEED);
  analogWrite(ENB, MOTOR_SPEED);
}

void pump(bool on) { digitalWrite(PIN_RELAY, on ? HIGH : LOW); }

void setState(State s) { state = s; stateStart = millis(); }

void setup() {
  pinMode(PIN_RELAY, OUTPUT);
  pinMode(ENA, OUTPUT); pinMode(ENB, OUTPUT);
  pinMode(IN1, OUTPUT); pinMode(IN2, OUTPUT);
  pinMode(IN3, OUTPUT); pinMode(IN4, OUTPUT);
  pump(false);
  motors(0);
  bt.begin(9600);
  Serial.begin(9600);
}

void loop() {
  char cmd = 0;
  while (bt.available()) cmd = bt.read();   // keep the latest command

  switch (state) {
    case IDLE:
      if (cmd == 'W') {
        motors(1);
        setState(FWD);
      } else if (cmd == 'S') {
        bt.write('D');                      // already home; re-confirm for CC
      }
      break;

    case FWD:
      if (millis() - stateStart >= DRIVE_MS) {
        motors(0);
        pump(true);
        setState(PUMPING);
      }
      break;

    case PUMPING:
      if (cmd == 'S' || millis() - stateStart >= PUMP_MAX_MS) {
        pump(false);
        motors(-1);
        setState(BWD);
      }
      break;

    case BWD:
      if (millis() - stateStart >= DRIVE_MS) {
        motors(0);
        bt.write('D');
        setState(IDLE);
      }
      break;
  }
}
