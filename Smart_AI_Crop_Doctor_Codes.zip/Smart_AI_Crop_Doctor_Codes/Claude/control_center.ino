// ===== CONTROL CENTER (CC) - Seeeduino v4.3 =====
// Grove Base Shield wiring:
//   Temp sensor  -> A0
//   Soil moisture-> A1
//   Buzzer       -> D6
//   RGB LCD      -> I2C
//   HC-05        -> D2 (HC-05 TX -> D2), D3 (D3 -> HC-05 RX, via 3.3V divider if bare module)
// Library needed: "Grove - LCD RGB Backlight" (rgb_lcd.h)

#include <Wire.h>
#include <math.h>
#include <SoftwareSerial.h>
#include "rgb_lcd.h"

const int PIN_TEMP   = A0;
const int PIN_MOIST  = A1;
const int PIN_BUZZER = 6;

SoftwareSerial bt(2, 3);   // RX, TX
rgb_lcd lcd;

// ---- Thresholds ----
const float TEMP_HOT        = 30.0;   // deg C
const int   MOIST_START     = 75;     // % : start watering below this
const int   MOIST_STOP      = 90;     // % : stop pump above this

// ---- Moisture calibration (CHECK THESE with your sensor!) ----
// Print raw values: dry in air = DRY_RAW, sensor in a glass of water = WET_RAW
const int DRY_RAW = 0;
const int WET_RAW = 700;

// ---- Timing ----
const unsigned long SAMPLE_MS   = 500;
const unsigned long COOLDOWN_MS = 30000UL;   // wait after a cycle so water can soak in
const unsigned long WATER_TIMEOUT_MS = 150000UL; // give up on a cycle after this
const unsigned long STOP_RESEND_MS = 2000;

// ---- State ----
float tempC = 0;
int   moisture = 0;
bool  sensorsOK = false;

bool watering = false;
bool stopSent = false;
unsigned long wateringStart = 0, lastStopSend = 0, lastDone = 0, lastSample = 0;
bool everDone = false;

// ---------- Sensors ----------
bool readTemp(float &t) {
  long sum = 0;
  for (int i = 0; i < 8; i++) { sum += analogRead(PIN_TEMP); delay(2); }
  int a = sum / 8;
  if (a <= 5 || a >= 1018) return false;       // open / shorted thermistor
  float R = 1023.0 / a - 1.0;
  R = 100000.0 * R;                             // Grove Temp v1.2 (B=4275, 100k)
  t = 1.0 / (log(R / 100000.0) / 4275.0 + 1.0 / 298.15) - 273.15;
  return (t > -40 && t < 125);
}

bool readMoisture(int &m) {
  long sum = 0;
  for (int i = 0; i < 8; i++) { sum += analogRead(PIN_MOIST); delay(2); }
  int a = sum / 8;
  if (a >= 1018) return false;                  // floating / shorted pin
  m = constrain(map(a, DRY_RAW, WET_RAW, 0, 100), 0, 100);
  return true;
}

// ---------- Display ----------
void rainbowBacklight() {
  static const uint8_t c[][3] = {{255,0,0},{255,128,0},{255,255,0},{0,255,0},{0,255,255},{0,0,255},{255,0,255}};
  static int idx = 0;
  static unsigned long last = 0;
  if (millis() - last > 200) {
    last = millis();
    idx = (idx + 1) % 7;
    lcd.setRGB(c[idx][0], c[idx][1], c[idx][2]);
  }
}

void showStatus() {
  lcd.setCursor(0, 0);
  if (!sensorsOK) {
    lcd.print("NO SENSOR READ  ");
    lcd.setCursor(0, 1);
    lcd.print("Check wiring!   ");
    return;
  }
  char l0[17], l1[17];
  char tbuf[8];
  dtostrf(tempC, 4, 1, tbuf);
  snprintf(l0, sizeof(l0), "T:%sC M:%3d%%   ", tbuf, moisture);

  const char *msg;
  if (tempC > TEMP_HOT)            msg = "TOO HOT!";
  else if (watering)               msg = "Watering...";
  else if (moisture < MOIST_START) msg = "Soil dry";
  else                             msg = "All good";
  snprintf(l1, sizeof(l1), "%-16s", msg);

  lcd.setCursor(0, 0); lcd.print(l0);
  lcd.setCursor(0, 1); lcd.print(l1);

  bool bad = (tempC > TEMP_HOT) || (moisture < MOIST_START);
  if (bad) lcd.setRGB(255, 0, 0);
  else     lcd.setRGB(0, 255, 0);
}

// ---------- Buzzer (non-blocking pulsing) ----------
void updateBuzzer() {
  static unsigned long last = 0;
  static bool on = false;
  if (sensorsOK && tempC > TEMP_HOT) {
    if (millis() - last >= 250) { last = millis(); on = !on; digitalWrite(PIN_BUZZER, on); }
  } else {
    on = false;
    digitalWrite(PIN_BUZZER, LOW);
  }
}

// ---------- Watering control ----------
void handleBluetooth() {
  while (bt.available()) {
    char c = bt.read();
    if (c == 'D' && watering) {            // car finished and is back home
      watering = false;
      stopSent = false;
      lastDone = millis();
      everDone = true;
    }
  }
}

void updateWatering() {
  unsigned long now = millis();

  if (!watering) {
    bool cooled = !everDone || (now - lastDone > COOLDOWN_MS);
    if (sensorsOK && moisture < MOIST_START && cooled) {
      bt.write('W');
      watering = true;
      stopSent = false;
      wateringStart = now;
    }
    return;
  }

  // Watering in progress: stop when wet enough, sensor fails, or timeout
  if (!stopSent && (!sensorsOK || moisture > MOIST_STOP || now - wateringStart > WATER_TIMEOUT_MS - 10000UL)) {
    bt.write('S');
    stopSent = true;
    lastStopSend = now;
  }
  // resend STOP until car confirms with 'D'
  if (stopSent && now - lastStopSend > STOP_RESEND_MS) {
    bt.write('S');
    lastStopSend = now;
  }
  // total failsafe so CC never gets stuck
  if (now - wateringStart > WATER_TIMEOUT_MS) {
    watering = false;
    stopSent = false;
    lastDone = now;
    everDone = true;
  }
}

void setup() {
  pinMode(PIN_BUZZER, OUTPUT);
  digitalWrite(PIN_BUZZER, LOW);
  bt.begin(9600);
  Serial.begin(9600);
  lcd.begin(16, 2);
  lcd.setRGB(0, 255, 0);
  lcd.print("Crop Doctor");
  delay(1000);
  lcd.clear();
}

void loop() {
  handleBluetooth();

  if (millis() - lastSample >= SAMPLE_MS) {
    lastSample = millis();
    float t; int m;
    bool okT = readTemp(t);
    bool okM = readMoisture(m);
    sensorsOK = okT && okM;
    if (okT) tempC = t;
    if (okM) moisture = m;
    showStatus();
    Serial.print("T="); Serial.print(tempC); Serial.print(" M="); Serial.print(moisture);
    Serial.print(" ok="); Serial.print(sensorsOK); Serial.print(" watering="); Serial.println(watering);
    updateWatering();
  }

  if (!sensorsOK) rainbowBacklight();
  updateBuzzer();
}
