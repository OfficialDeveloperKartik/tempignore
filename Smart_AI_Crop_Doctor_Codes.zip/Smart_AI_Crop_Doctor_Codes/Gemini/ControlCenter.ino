#include <Wire.h>
#include "rgb_lcd.h"
#include <SoftwareSerial.h>

rgb_lcd lcd;
SoftwareSerial btSerial(2, 3); // RX, TX (Connect to HC-05)

const int TEMP_PIN = A0;
const int MOISTURE_PIN = A1;
const int BUZZER_PIN = 4;

bool isWatering = false;
unsigned long buzzerMillis = 0;
bool buzzerState = false;

void setup() {
  Serial.begin(9600);
  btSerial.begin(9600);
  
  pinMode(BUZZER_PIN, OUTPUT);
  
  lcd.begin(16, 2);
  lcd.setRGB(0, 255, 0); // Start Green
  lcd.print("AI Crop Doctor");
  delay(2000);
  lcd.clear();
}

void loop() {
  // Read Sensors
  int tempRaw = analogRead(TEMP_PIN);
  int moistRaw = analogRead(MOISTURE_PIN);

  // Check for sensor disconnect / damage (rail values)
  bool sensorError = (tempRaw <= 5 || tempRaw >= 1020 || moistRaw <= 5 || moistRaw >= 1020);

  if (sensorError) {
    // Flashing all colors for sensor error state
    static unsigned long flashMillis = 0;
    if (millis() - flashMillis > 500) {
      flashMillis = millis();
      static int colorToggle = 0;
      if (colorToggle == 0) lcd.setRGB(255, 0, 0);
      else if (colorToggle == 1) lcd.setRGB(0, 255, 0);
      else lcd.setRGB(0, 0, 255);
      colorToggle = (colorToggle + 1) % 3;
    }
    lcd.setCursor(0, 0);
    lcd.print("Sensor Error!   ");
    lcd.setCursor(0, 1);
    lcd.print("Check Wiring    ");
    return; 
  }

  // Convert Grove Temperature Sensor reading (Approximate NTC thermistor calculation)
  float resistance = (1023.0 / (float)tempRaw - 1.0) * 10000.0;
  float temperature = 1.0 / (log(resistance / 10000.0) / 3975.0 + 1.0 / 298.15) - 273.15;

  // Convert Soil Moisture reading to percentage 
  // Note: Adjust 800 (dry) and 300 (wet) thresholds based on your specific sensor calibration
  int moisturePercent = map(moistRaw, 800, 300, 0, 100); 
  moisturePercent = constrain(moisturePercent, 0, 100);

  // Threshold Checks
  bool highTemp = temperature > 30.0;
  bool lowMoisture = moisturePercent < 75;

  // RGB LCD Color Control
  if (highTemp || lowMoisture) {
    lcd.setRGB(255, 0, 0); // Red
  } else {
    lcd.setRGB(0, 255, 0); // Green
  }

  // Display status on LCD
  lcd.setCursor(0, 0);
  lcd.print("T:");
  lcd.print(temperature, 1);
  lcd.print("C ");
  lcd.print("M:");
  lcd.print(moisturePercent);
  lcd.print("%   ");

  lcd.setCursor(0, 1);
  if (isWatering) {
    lcd.print("Status: Watering");
  } else if (lowMoisture) {
    lcd.print("Status: Dry(<75%)");
  } else {
    lcd.print("Status: Optimal ");
  }

  // Pulsating Buzzer for Temperature > 30°C
  if (highTemp) {
    if (millis() - buzzerMillis > 300) {
      buzzerMillis = millis();
      buzzerState = !buzzerState;
      digitalWrite(BUZZER_PIN, buzzerState ? HIGH : LOW);
    }
  } else {
    digitalWrite(BUZZER_PIN, LOW);
  }

  // Bluetooth Watering Protocol Trigger
  if (!isWatering && moisturePercent < 75) {
    btSerial.println("START_WATER");
    isWatering = true;
  } else if (isWatering && moisturePercent > 90) {
    btSerial.println("STOP_WATER");
    isWatering = false;
  }

  delay(500);
}