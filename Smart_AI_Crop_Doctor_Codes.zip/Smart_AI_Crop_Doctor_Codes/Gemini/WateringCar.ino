#include <SoftwareSerial.h>

SoftwareSerial btSerial(2, 3); // RX, TX (Connect to HC-05)

// L298N Motor Driver Pins (4WD paired into 2 driver channels)
const int IN1 = 6;
const int IN2 = 7;
const int IN3 = 8;
const int IN4 = 9;

// Grove Relay Pin
const int RELAY_PIN = 4;

enum CarState { IDLE, MOVING_FORWARD, PUMPING, MOVING_BACKWARD };
CarState carState = IDLE;

void setup() {
  Serial.begin(9600);
  btSerial.begin(9600);

  pinMode(IN1, OUTPUT);
  pinMode(IN2, OUTPUT);
  pinMode(IN3, OUTPUT);
  pinMode(IN4, OUTPUT);
  pinMode(RELAY_PIN, OUTPUT);

  digitalWrite(RELAY_PIN, LOW); // Ensure pump is OFF initially
  stopMotors();
}

void loop() {
  // Listen for instructions from the Control Center
  if (btSerial.available()) {
    String command = btSerial.readStringUntil('\n');
    command.trim();

    if (command == "START_WATER" && carState == IDLE) {
      executeWateringRoutine();
    }
  }
}

void executeWateringRoutine() {
  carState = MOVING_FORWARD;

  // 1. Drive forward for 3 seconds
  moveForward();
  delay(3000);
  stopMotors();

  // 2. Turn on pump through Grove relay
  carState = PUMPING;
  digitalWrite(RELAY_PIN, HIGH);

  // 3. Stay pumping until CC sends "STOP_WATER" (when moisture > 90%)
  while (true) {
    if (btSerial.available()) {
      String cmd = btSerial.readStringUntil('\n');
      cmd.trim();
      if (cmd == "STOP_WATER") {
        break;
      }
    }
    delay(100);
  }

  // 4. Turn off pump
  digitalWrite(RELAY_PIN, LOW);

  // 5. Drive backward for 3 seconds to reset assembly
  carState = MOVING_BACKWARD;
  moveBackward();
  delay(3000);
  stopMotors();

  carState = IDLE;
}

void moveForward() {
  digitalWrite(IN1, HIGH);
  digitalWrite(IN2, LOW);
  digitalWrite(IN3, HIGH);
  digitalWrite(IN4, LOW);
}

void moveBackward() {
  digitalWrite(IN1, LOW);
  digitalWrite(IN2, HIGH);
  digitalWrite(IN3, LOW);
  digitalWrite(IN4, HIGH);
}

void stopMotors() {
  digitalWrite(IN1, LOW);
  digitalWrite(IN2, LOW);
  digitalWrite(IN3, LOW);
  digitalWrite(IN4, LOW);
}