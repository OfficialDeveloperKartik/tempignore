
#include <SoftwareSerial.h>
#include <Wire.h>
#include "rgb_lcd.h"
#include <math.h>

SoftwareSerial bt(2, 3); // RX, TX
rgb_lcd lcd;

const int SOIL_PIN = A0;
const int TEMP_PIN = A1;
const int BUZZER_PIN = 4;

// Replace these with your measured calibration readings.
const int DRY_RAW = 800;
const int WET_RAW = 300;

int moisture = 0;
float temperature = 0;
bool soilValid = false;
bool tempValid = false;
bool watering = false;
bool hot = false;

unsigned long lastRead = 0;
unsigned long lastSend = 0;
unsigned long lastDisplay = 0;
unsigned long lastBuzzer = 0;
bool buzzerOn = false;
bool rgbFlash = false;

String incoming = "";

int readAverage(int pin) {
  long sum = 0;
  for (int i = 0; i < 8; i++) {
    sum += analogRead(pin);
    delay(2);
  }
  return sum / 8;
}

int readMoisture(int raw) {
  // Supports either sensor polarity.
  float pct = 100.0 * (raw - DRY_RAW) /
              (float)(WET_RAW - DRY_RAW);
  return constrain((int)(pct + 0.5), 0, 100);
}

float readThermistorC(int raw) {
  // Common Grove NTC thermistor starting formula.
  // Confirm B and R0 for your particular module.
  const float B = 3975.0;
  const float R0 = 100000.0;

  float resistance = R0 * (1023.0 / raw - 1.0);
  return 1.0 /
    (log(resistance / R0) / B + 1.0 / 298.15)
    - 273.15;
}

void receiveBluetooth() {
  while (bt.available()) {
    char c = bt.read();

    if (c == '\n') {
      incoming.trim();

      if (incoming == "DONE") {
        watering = false;
      } else if (incoming.startsWith("FAULT")) {
        watering = false;
      }

      incoming = "";
    } else if (c != '\r' && incoming.length() < 40) {
      incoming += c;
    }
  }
}

void setup() {
  pinMode(BUZZER_PIN, OUTPUT);
  digitalWrite(BUZZER_PIN, LOW);

  Serial.begin(9600);
  bt.begin(9600);

  lcd.begin(16, 2);
  lcd.setRGB(0, 255, 0);
  lcd.setCursor(0, 0);
  lcd.print("Crop Doctor");
  lcd.setCursor(0, 1);
  lcd.print("Starting...");
  delay(1000);
}

void loop() {
  unsigned long now = millis();
  receiveBluetooth();

  if (now - lastRead >= 500) {
    lastRead = now;

    int soilRaw = readAverage(SOIL_PIN);
    int tempRaw = readAverage(TEMP_PIN);

    // Extreme readings often indicate a disconnected sensor.
    // Adjust these limits after inspecting your hardware.
    soilValid = soilRaw > 5 && soilRaw < 1018;
    tempValid = tempRaw > 5 && tempRaw < 1018;

    if (soilValid) {
      moisture = readMoisture(soilRaw);
    }

    if (tempValid) {
      temperature = readThermistorC(tempRaw);
      tempValid = isfinite(temperature) &&
                  temperature >= -20 &&
                  temperature <= 80;
    }

    // Temperature hysteresis.
    if (tempValid) {
      if (temperature > 30.0) hot = true;
      if (temperature < 29.0) hot = false;
    }
  }

  // Send fresh soil data to the car.
  if (now - lastSend >= 500) {
    lastSend = now;

    if (soilValid) {
      bt.print("M,");
      bt.println(moisture);
    } else {
      bt.println("SENSOR_ERROR");
    }

    // Start only once per cycle.
    if (soilValid && !watering && moisture < 75) {
      bt.println("WATER");
      watering = true;
    }
  }

  // Pulsating buzzer, without blocking sensor updates.
  if (now - lastBuzzer >= 250) {
    lastBuzzer = now;
    buzzerOn = !buzzerOn;
    digitalWrite(BUZZER_PIN, hot && buzzerOn ? HIGH : LOW);
  }

  // Update the display periodically.
  if (now - lastDisplay >= 250) {
    lastDisplay = now;

    bool fault = !soilValid || !tempValid;

    if (fault) {
      rgbFlash = !rgbFlash;
      lcd.setRGB(rgbFlash ? 255 : 0,
                 rgbFlash ? 0 : 0,
                 rgbFlash ? 255 : 0);
      lcd.setCursor(0, 0);
      lcd.print("SENSOR ERROR!   ");
      lcd.setCursor(0, 1);
      lcd.print("Check readings ");
    } else {
      lcd.setRGB(
        hot || moisture < 75 ? 255 : 0,
        hot || moisture < 75 ? 0 : 180,
        0
      );

      lcd.setCursor(0, 0);
      lcd.print("TEMP:");
      lcd.print(temperature, 1);
      lcd.print(" C       ");

      lcd.setCursor(0, 1);
      lcd.print("SOIL:");
      lcd.print(moisture);
      lcd.print("% ");
      lcd.print(watering ? "WATERING" : "       ");
    }
  }
}
