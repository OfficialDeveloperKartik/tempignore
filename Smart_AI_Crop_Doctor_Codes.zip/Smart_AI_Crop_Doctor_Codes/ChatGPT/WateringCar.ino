
#include <SoftwareSerial.h>

SoftwareSerial bt(2, 3); // RX, TX

const int RELAY_PIN = 4;

const int IN1 = 5;
const int IN2 = 6;
const int IN3 = 9;
const int IN4 = 10;

// Verify polarity for your relay module.
const int RELAY_ON = LOW;
const int RELAY_OFF = HIGH;

const unsigned long MOVE_TIME = 3000;
const unsigned long MAX_PUMP_TIME = 60000;
const unsigned long MOISTURE_TIMEOUT = 3000;

enum State {
  IDLE,
  MOVING_FORWARD,
  PUMPING,
  MOVING_BACKWARD
};

State state = IDLE;

unsigned long stateStart = 0;
unsigned long lastMoistureTime = 0;

int moisture = -1;
bool moistureValid = false;
String incoming = "";

void stopMotors() {
  digitalWrite(IN1, LOW);
  digitalWrite(IN2, LOW);
  digitalWrite(IN3, LOW);
  digitalWrite(IN4, LOW);
}

void forward() {
  digitalWrite(IN1, HIGH);
  digitalWrite(IN2, LOW);
  digitalWrite(IN3, HIGH);
  digitalWrite(IN4, LOW);
}

void backward() {
  digitalWrite(IN1, LOW);
  digitalWrite(IN2, HIGH);
  digitalWrite(IN3, LOW);
  digitalWrite(IN4, HIGH);
}

void pump(bool on) {
  digitalWrite(RELAY_PIN, on ? RELAY_ON : RELAY_OFF);
}

void report(const char *message) {
  bt.println(message);
  Serial.println(message);
}

void beginCycle() {
  if (state != IDLE) return;

  if (!moistureValid ||
      millis() - lastMoistureTime > MOISTURE_TIMEOUT) {
    report("FAULT,NO_MOISTURE");
    return;
  }

  state = MOVING_FORWARD;
  stateStart = millis();

  stopMotors();
  pump(false);
  forward();

  report("MOVING_FWD");
}

void finishCycle() {
  pump(false);
  stopMotors();

  state = IDLE;
  report("DONE");
}

void failCycle(const char *reason) {
  pump(false);
  stopMotors();

  state = IDLE;
  report(reason);
}

void handleMessage(String msg) {
  msg.trim();

  if (msg == "WATER") {
    beginCycle();
  }
  else if (msg == "SENSOR_ERROR") {
    moistureValid = false;

    if (state == PUMPING) {
      failCycle("FAULT,SENSOR");
    }
  }
  else if (msg.startsWith("M,")) {
    int value = msg.substring(2).toInt();

    if (value >= 0 && value <= 100) {
      moisture = value;
      moistureValid = true;
      lastMoistureTime = millis();
    }
  }
}

void receiveBluetooth() {
  while (bt.available()) {
    char c = bt.read();

    if (c == '\n') {
      handleMessage(incoming);
      incoming = "";
    } else if (c != '\r' && incoming.length() < 40) {
      incoming += c;
    }
  }
}

void setup() {
  pinMode(RELAY_PIN, OUTPUT);
  pinMode(IN1, OUTPUT);
  pinMode(IN2, OUTPUT);
  pinMode(IN3, OUTPUT);
  pinMode(IN4, OUTPUT);

  pump(false);
  stopMotors();

  Serial.begin(9600);
  bt.begin(9600);

  report("WC_READY");
}

void loop() {
  receiveBluetooth();

  unsigned long now = millis();

  switch (state) {
    case IDLE:
      break;

    case MOVING_FORWARD:
      if (now - stateStart >= MOVE_TIME) {
        stopMotors();

        if (!moistureValid ||
            now - lastMoistureTime > MOISTURE_TIMEOUT) {
          failCycle("FAULT,NO_MOISTURE");
          break;
        }

        state = PUMPING;
        stateStart = now;
        pump(true);
        report("PUMP_ON");
      }
      break;

    case PUMPING:
      if (!moistureValid ||
          now - lastMoistureTime > MOISTURE_TIMEOUT) {
        failCycle("FAULT,NO_MOISTURE");
      }
      else if (moisture > 90) {
        pump(false);

        state = MOVING_BACKWARD;
        stateStart = now;
        backward();

        report("PUMP_OFF");
        report("MOVING_BACK");
      }
      else if (now - stateStart >= MAX_PUMP_TIME) {
        failCycle("FAULT,PUMP_TIMEOUT");
      }
      break;

    case MOVING_BACKWARD:
      if (now - stateStart >= MOVE_TIME) {
        stopMotors();
        finishCycle();
      }
      break;
  }
}
