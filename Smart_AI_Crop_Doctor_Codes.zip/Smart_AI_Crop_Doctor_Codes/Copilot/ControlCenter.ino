#include <Wire.h>
#include "rgb_lcd.h"
#include <SoftwareSerial.h>
#include <math.h>

rgb_lcd lcd;
SoftwareSerial BT(2, 3);   // RX, TX

const int TEMP_PIN = A0;
const int MOISTURE_PIN = A1;
const int BUZZER_PIN = 5;

const float TEMP_LIMIT = 30.0;
const int START_WATER = 75;
const int STOP_WATER = 90;

bool wateringActive = false;

unsigned long lastBuzz = 0;
bool buzzState = false;

void setup()
{
    Serial.begin(9600);
    BT.begin(9600);

    pinMode(BUZZER_PIN, OUTPUT);

    lcd.begin(16, 2);
    lcd.setRGB(0, 255, 0);

    lcd.clear();
    lcd.print("Smart Crop Dr");
    delay(1500);
}

void loop()
{
    float temperature = readTemperature();
    int moisture = readMoisture();

    bool tempError =
        isnan(temperature) ||
        temperature < -20 ||
        temperature > 80;

    bool moistError =
        moisture < 0 ||
        moisture > 100;

    if(tempError || moistError)
    {
        sensorErrorMode();
        return;
    }

    if(moisture < START_WATER && !wateringActive)
    {
        BT.println("WATER");
        wateringActive = true;

        Serial.println("Sent WATER");
    }

    if(moisture > STOP_WATER && wateringActive)
    {
        BT.println("STOP");
        wateringActive = false;

        Serial.println("Sent STOP");
    }

    lcd.clear();

    lcd.setCursor(0,0);
    lcd.print("T:");
    lcd.print(temperature,1);
    lcd.print("C");

    lcd.setCursor(0,1);
    lcd.print("M:");
    lcd.print(moisture);
    lcd.print("%");

    if(temperature > TEMP_LIMIT || moisture < START_WATER)
    {
        lcd.setRGB(255,0,0);
    }
    else
    {
        lcd.setRGB(0,255,0);
    }

    controlBuzzer(temperature);

    delay(500);
}

float readTemperature()
{
    int value = analogRead(TEMP_PIN);

    float resistance =
        (1023.0 - value) * 10000.0 / value;

    float temperature =
        1.0 /
        (log(resistance / 10000.0) / 3975.0 +
        1.0 / 298.15) - 273.15;

    return temperature;
}

int readMoisture()
{
    int raw = analogRead(MOISTURE_PIN);

    int moisture =
        map(raw, 1023, 0, 0, 100);

    moisture = constrain(moisture,0,100);

    return moisture;
}

void controlBuzzer(float temp)
{
    if(temp > TEMP_LIMIT)
    {
        if(millis() - lastBuzz > 300)
        {
            buzzState = !buzzState;

            digitalWrite(BUZZER_PIN,buzzState);

            lastBuzz = millis();
        }
    }
    else
    {
        digitalWrite(BUZZER_PIN,LOW);
    }
}

void sensorErrorMode()
{
    static int colour = 0;

    lcd.clear();

    lcd.setCursor(0,0);
    lcd.print("SENSOR ERROR");

    switch(colour)
    {
        case 0: lcd.setRGB(255,0,0); break;
        case 1: lcd.setRGB(0,255,0); break;
        case 2: lcd.setRGB(0,0,255); break;
        case 3: lcd.setRGB(255,255,0); break;
        case 4: lcd.setRGB(0,255,255); break;
        case 5: lcd.setRGB(255,0,255); break;
    }

    colour++;

    if(colour > 5)
        colour = 0;

    delay(250);
}