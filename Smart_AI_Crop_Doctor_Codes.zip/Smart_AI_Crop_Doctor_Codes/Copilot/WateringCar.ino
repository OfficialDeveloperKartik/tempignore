#include <SoftwareSerial.h>

SoftwareSerial BT(2,3);

const int RELAY = 4;

// L298N

const int ENA = 5;
const int IN1 = 6;
const int IN2 = 7;

const int ENB = 9;
const int IN3 = 10;
const int IN4 = 11;

bool watering = false;

void setup()
{
    BT.begin(9600);

    pinMode(RELAY, OUTPUT);

    pinMode(ENA, OUTPUT);
    pinMode(IN1, OUTPUT);
    pinMode(IN2, OUTPUT);

    pinMode(ENB, OUTPUT);
    pinMode(IN3, OUTPUT);
    pinMode(IN4, OUTPUT);

    digitalWrite(RELAY, LOW);

    stopMotors();
}

void loop()
{
    if(BT.available())
    {
        String cmd = BT.readStringUntil('\n');

        cmd.trim();

        if(cmd == "WATER")
        {
            startWatering();
        }

        if(cmd == "STOP")
        {
            stopWatering();
        }
    }
}

void startWatering()
{
    if(watering) return;

    watering = true;

    moveForward();

    delay(3000);

    stopMotors();

    digitalWrite(RELAY, HIGH);
}

void stopWatering()
{
    if(!watering) return;

    digitalWrite(RELAY, LOW);

    moveBackward();

    delay(3000);

    stopMotors();

    watering = false;
}

void moveForward()
{
    analogWrite(ENA, 180);
    analogWrite(ENB, 180);

    digitalWrite(IN1, HIGH);
    digitalWrite(IN2, LOW);

    digitalWrite(IN3, HIGH);
    digitalWrite(IN4, LOW);
}

void moveBackward()
{
    analogWrite(ENA, 180);
    analogWrite(ENB, 180);

    digitalWrite(IN1, LOW);
    digitalWrite(IN2, HIGH);

    digitalWrite(IN3, LOW);
    digitalWrite(IN4, HIGH);
}

void stopMotors()
{
    digitalWrite(IN1, LOW);
    digitalWrite(IN2, LOW);

    digitalWrite(IN3, LOW);
    digitalWrite(IN4, LOW);
}